var request = JSON.parse(context.getVariable('standardInput'));
var convertedReq = {
    "fields": ""
};
var keys = [];
var fields = {};
var requestError = false;
try {
    if (request === undefined || request === null || request === "") {
        requestError = true;
    }
} catch (e) {
    requestError = true;
}

if (!requestError) {
    var subObject = {};
    var field = "";
    for (var i in request) {
        if (Object.prototype.toString.call(request[i]) === "[object String]") {
            field = {
                "stringValue": request[i].toString()
            };
            subObject[i] = field;
        } else if(Object.prototype.toString.call(request[i]) === "[object Number]") {
            field = {
                "doubleValue": request[i]
            };
            subObject[i] = field;
        } else if (Object.prototype.toString.call(request[i]) === "[object Array]") {
            field = {
                "arrayValue": {
                    "values": JSON.parse(parseObject(request[i], "array"))
                }
            };
            subObject[i] = field;
        } else if (Object.prototype.toString.call(request[i]) === "[object Object]") {
            field = {
                "mapValue": JSON.parse(parseObject(request[i], "object"))
            };
        }
    }
    convertedReq.fields = subObject;
    context.setVariable('firestoreOutput', JSON.stringify(convertedReq));
}


function parseObject(jsonObject, type) {
    if (type === "array") {
        var subObject = [];
        for (var arrayIndex = 0; arrayIndex < jsonObject.length; arrayIndex++) {
            if (Object.prototype.toString.call(jsonObject[arrayIndex]) === "[object String]") {
                subObject[arrayIndex] = {
                    "stringValue": jsonObject[arrayIndex].toString()
                };
            } else if (Object.prototype.toString.call(jsonObject[arrayIndex]) === "[object Number]") {
                subObject[arrayIndex] = {
                    "doubleValue": jsonObject[arrayIndex]
                };
            } else if (Object.prototype.toString.call(jsonObject[arrayIndex]) === "[object Array]") {
                subObject[arrayIndex] = {
                    "arrayValue": {
                        "values": JSON.parse(parseObject(jsonObject[arrayIndex], "array"))
                    }
                };
            } else if (Object.prototype.toString.call(jsonObject[arrayIndex]) === "[object Object]") {
                subObject[arrayIndex] = {
                    "mapValue": JSON.parse(parseObject(jsonObject[arrayIndex], "object"))
                };
            }
        }
        return JSON.stringify(subObject);
    } else if (type === "object") {
        var subObject = {
            "fields": ""
        };
        var subFields = {};
        for (var k in jsonObject) {
            if (Object.prototype.toString.call(jsonObject[k]) === "[object String]") {
                subFields[k] = {
                    "stringValue": jsonObject[k].toString()
                };
                subObject.fields = subFields;
            } else if (Object.prototype.toString.call(jsonObject[k]) === "[object Number]") {
                subFields[k] = {
                    "doubleValue": jsonObject[k]
                };
                subObject.fields = subFields;
            } else if (Object.prototype.toString.call(jsonObject[k]) === "[object Array]") {
                subFields[k] = {
                    "arrayValue": {
                        "values": JSON.parse(parseObject(jsonObject[k], "array"))
                    }
                };
                subObject.fields = subFields;
            } else if (Object.prototype.toString.call(jsonObject[k]) === "[object Object]") {
                subFields[k] = {
                    "mapValue": JSON.parse(parseObject(jsonObject[k], "object"))
                };
                subObject.fields = subFields;
            }
        }
        return JSON.stringify(subObject);
    }
}