var res = JSON.parse(context.getVariable("firestoreInput"));
var convertedRes = {};
var keys = [];
var firestoreError = false;
try {
    if (Object.prototype.toString.call(res) === "[object Array]") {
        if (res[0].document === undefined) {
            firestoreError = true;
        } else {
            res = res[0].document.fields;
        }
    } else if (Object.prototype.toString.call(res) === "[object Object]") {
        if (res.name === undefined) {
            firestoreError = true;
        } else {
            res = res.fields;
        }
    }
} catch (e) {
    firestoreError = true;
}


if (firestoreError === false) {
    for (var k in res) {
        keys.push(k);
    }
    for (var i = 0; i < keys.length; i++) {
        var field = res[keys[i]];
        for (k in field) {
            if (k === "stringValue" || k === "integerValue" || k === "doubleValue") {
                convertedRes[keys[i]] = field[k];
            } else if (k === "mapValue") {
                convertedRes[keys[i]] = JSON.parse(parseObject(field[k].fields, "jsonObj"));
            } else if (k === "arrayValue") {
                convertedRes[keys[i]] = JSON.parse(parseObject(field[k].values, "array"));
            }
        }
    }
    context.setVariable("standardOutput", JSON.stringify(convertedRes));
}

function parseObject(jsonObject, type) {
    if (type === "jsonObj") {
        var subObject = {};
        var keys = [];
        for (k in jsonObject) {
            keys.push(k);
        }
        for (var i = 0; i < keys.length; i++) {
            var field = jsonObject[keys[i]];
            for (k in field) {
                if (k === "stringValue" || k === "integerValue" || k === "doubleValue") {
                    subObject[keys[i]] = field[k];
                } else if (k === "mapValue") {
                    subObject[keys[i]] = JSON.parse(parseObject(field[k].fields, "jsonObj"));
                } else if (k === "arrayValue") {
                    subObject[keys[i]] = JSON.parse(parseObject(field[k].values, "array"));
                }
            }
        }
        return JSON.stringify(subObject);
    } else if (type === "array") {
        var subObject = [];
        for (var arrayIndex = 0; arrayIndex < jsonObject.length; arrayIndex++) {
            for (k in jsonObject[arrayIndex])
                if (k === "stringValue") {
                    subObject[arrayIndex] = jsonObject[arrayIndex][k];
                } else if (k === "integerValue" || k === "doubleValue") {
                subObject[arrayIndex] = jsonObject[arrayIndex][k];
            } else if (k === "mapValue") {
                subObject[arrayIndex] = JSON.parse(parseObject(jsonObject[arrayIndex].mapValue.fields, "jsonObj"));
            }
        }
        return JSON.stringify(subObject);
    }
}
context.setVariable("firestoreError", firestoreError);